for line in open('1.txt','r'):
  line = line.rstrip()
  if line != '':
    print line
