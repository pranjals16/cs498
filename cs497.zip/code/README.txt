This folder contains the code for deducig sentiment and emotions from text in two differnt ways:
For the Supervised way , the code is in C:
	-open the "supervised" folder, open "codes" folder.
	-run "./sentiment" to enter the text and get the required sentiment and score.
	-more information can be found in the reaadme inside the folder as the implementation is by Alchemy API.

For the Unsupervised way, the code is in Python:
	-run main.py
	-the  code may take quite a time as per the training data.
	-more information can be found itself in the "plsa.py" file.
	
Read the report to know about the code.